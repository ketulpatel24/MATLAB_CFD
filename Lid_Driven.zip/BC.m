function [u,v,w]=BC(Nx,Ny,Nz,u,v,w)
    %BC for u
    for k=1:Nz+2
        for j=1:Ny+2
            for i=1:Nx+1
                %x-direction
                u(1,j,k)=0;
                u(Nx+1,j,k)=0;
                %y-direction
                u(i,1,k)=u(i,Ny+1,k);
                u(i,Ny+2,k)=u(i,2,k);
                %z-direction
                u(i,j,1)=-u(i,j,2);
                u(i,j,Nz+2)=2-u(i,j,Nz+1);
            end
        end
    end
    
    %BC for v
    for k=1:Nz+2
        for j=1:Ny+1
            for i=1:Nx+2
                %x-direction
                v(1,j,k)=-v(2,j,k);
                v(Nx+2,j,k)=-v(Nx+1,j,k);
                %y-direction
                v(i,1,k)=v(i,Ny,k);
                v(i,Ny+1,k)=v(i,2,k);
                %z-direction
                v(i,j,1)=-v(i,j,2);
                v(i,j,Nz+2)=-v(i,j,Nz+1);
            end
        end
    end
    
    %BC for w
    for k=1:Nz+1
        for j=1:Ny+2
            for i=1:Nx+2
                %x-direction
                w(1,j,k)=-w(2,j,k);
                w(Nx+2,j,k)=-w(Nx+1,j,k);
                %y-direction
                w(i,1,k)=w(i,Ny+1,k);
                w(i,Ny+2,k)=w(i,2,k);
                %z-direction
                w(i,j,1)=0;
                w(i,j,Nz+1)=0;
            end
        end
    end
end