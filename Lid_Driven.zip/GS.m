function [up,vp,wp]=GS(Nx,Ny,Nz,dt,dzc,u,v,w,qu,qv,qw,C2,Re)
    %Given Initial values to up
    for k=1:Nz+2
        for j=1:Nz+2
            for i=1:Nx+1
                up(i,j,k)=0;  
                up0(i,j,k)=0;
            end
        end
    end
    
    %Given Initial values to vp
    for k=1:Nz+2
        for j=1:Nz+1
            for i=1:Nx+2
                vp(i,j,k)=0;  
                vp0(i,j,k)=0;
            end
        end
    end
    
    %Given Initial values to wp
    for k=1:Nz+1
        for j=1:Nz+2
            for i=1:Nx+2
                wp(i,j,k)=0;  
                wp0(i,j,k)=0;
            end
        end
    end
    
    [up,vp,wp]=BC(Nx,Ny,Nz,up,vp,wp);
    [up0,vp0,wp0]=BC(Nx,Ny,Nz,up0,vp0,wp0);
    %Calculation of coeeficients
for k=2:Nz+1
    for j=2:Ny+1
        for i=2:Nx+1
            ae(i,j,k)=0; aw(i,j,k)=0;
            an(i,j,k)=0; as(i,j,k)=0;
            at(i,j,k)=-dt/(Re*power(dzc,2)); ab(i,j,k)=-dt/(Re*power(dzc,2));
            ap(i,j,k)=1-ae(i,j,k)-aw(i,j,k)-an(i,j,k)-as(i,j,k)-at(i,j,k)-ab(i,j,k);
        end
    end
end

%calculate RHS terms for up
    for k=2:Nz+1
        for j=2:Ny+1
            for i=2:Nx
                rtempu(i,j,k)=u(i,j,k)+C2*qu(i,j,k);
            end
        end
    end
    
    %calculate RHS for vp
    for k=2:Nz+1
        for j=2:Ny
            for i=2:Nx+1
                rtempv(i,j,k)=v(i,j,k)+C2*qv(i,j,k);
            end
        end
    end
    
    %calculate RHS for wp
    for k=2:Nz
        for j=2:Ny+1
            for i=2:Nx+1
                rtempw(i,j,k)=w(i,j,k)+C2*qw(i,j,k);
            end
        end
    end
    
    %Main Loop for up
count=0;L2norm=1.0;
while (L2norm>0.0000001) && (count<5000)    
for k=2:Nz+1
    for j=2:Ny+1
        for i=2:Nx
            %Calculation of Phi
            up(i,j,k)=(rtempu(i,j,k)-at(i,j,k)*up(i,j,k+1)-ab(i,j,k)*up(i,j,k-1))/ap(i,j,k);
         end
    end
end

%update BC for up
    for k=1:Nz+2
        for j=1:Ny+2
            for i=1:Nx+1
                %x-direction
                up(1,j,k)=0;
                up(Nx+1,j,k)=0;
                %y-direction
                up(i,1,k)=up(i,Ny+1,k);
                up(i,Ny+2,k)=up(i,2,k);
                %z-direction
                up(i,j,1)=-up(i,j,2);
                up(i,j,Nz+2)=2-up(i,j,Nz+1);
            end
        end
    end
sum=0;
%Calculation of Sum of Square of Difference between new and old values
for k=1:Nz+2
    for j=1:Ny+2
        for i=1:Nx+1
            sum=sum+power(up(i,j,k)-up0(i,j,k),2);
        end
    end
end
    L2norm=sqrt(sum);       %Calculation of L2norm Value
    %disp(L2norm)

%storing current loop phi value in another 3D array
for k=1:Nz+2
    for j=1:Ny+2
        for i=1:Nx+1
            up0(i,j,k)=up(i,j,k);   
        end
    end
end


count=count+1;
end

%Main Loop for vp
count=0;L2norm=1.0;
while (L2norm>0.0000001) && (count<5000)    
for k=2:Nz+1
    for j=2:Ny
        for i=2:Nx+1
            %Calculation of Phi
            vp(i,j,k)=(rtempv(i,j,k)-at(i,j,k)*vp(i,j,k+1)-ab(i,j,k)*vp(i,j,k-1))/ap(i,j,k);
         end
    end
end

%update BC for up
    for k=1:Nz+2
        for j=1:Ny+1
            for i=1:Nx+2
                %x-direction
                vp(1,j,k)=-vp(2,j,k);
                vp(Nx+2,j,k)=-vp(Nx+1,j,k);
                %y-direction
                vp(i,1,k)=vp(i,Ny,k);
                vp(i,Ny+1,k)=vp(i,2,k);
                %z-direction
                vp(i,j,1)=-vp(i,j,2);
                vp(i,j,Nz+2)=-vp(i,j,Nz+1);
            end
        end
    end
sum=0;
%Calculation of Sum of Square of Difference between new and old values
for k=1:Nz+2
    for j=1:Ny+1
        for i=1:Nx+2
            sum=sum+power(vp(i,j,k)-vp0(i,j,k),2);
        end
    end
end
    L2norm=sqrt(sum);       %Calculation of L2norm Value
    %disp(L2norm)

%storing current loop phi value in another 3D array
for k=1:Nz+2
    for j=1:Ny+1
        for i=1:Nx+2
            vp0(i,j,k)=vp(i,j,k);   
        end
    end
end


count=count+1;
end

%Main Loop for wp
count=0;L2norm=1.0;
while (L2norm>0.0000001) && (count<5000) 
for k=2:Nz
    for j=2:Ny+1
        for i=2:Nx+1
            
            %Calculation of Phi
            wp(i,j,k)=(rtempw(i,j,k)-at(i,j,k)*wp(i,j,k+1)-ab(i,j,k)*wp(i,j,k-1))/ap(i,j,k);
         end
    end
end

%update BC for wp
    for k=1:Nz+1
        for j=1:Ny+2
            for i=1:Nx+2
                %x-direction
                wp(1,j,k)=-wp(2,j,k);
                wp(Nx+2,j,k)=-wp(Nx+1,j,k);
                %y-direction
                wp(i,1,k)=wp(i,Ny+1,k);
                wp(i,Ny+2,k)=wp(i,2,k);
                %z-direction
                wp(i,j,1)=0;
                wp(i,j,Nz+1)=0;
            end
        end
    end
sum=0;
%Calculation of Sum of Square of Difference between new and old values
for k=1:Nz+1
    for j=1:Ny+2
        for i=1:Nx+2
            sum=sum+power(wp(i,j,k)-wp0(i,j,k),2);
        end
    end
end
    L2norm=sqrt(sum);       %Calculation of L2norm Value
    %disp(L2norm)

%storing current loop phi value in another 3D array
for k=1:Nz+1
    for j=1:Ny+2
        for i=1:Nx+2
            wp0(i,j,k)=wp(i,j,k);   
        end
    end
end
 

count=count+1;
end

end