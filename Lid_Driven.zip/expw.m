function [wtemp]=expw(Nx,Ny,Nz,u,v,w,xe,xc,ye,yc,ze,zc,Re)
    for k=2:Nz
        for j=2:Ny+1
            for i=2:Nx+1
                %calculation of convective v terms
                wave1=0.5*(w(i,j,k)+w(i,j,k-1));
                wave2=0.5*(w(i,j,k+1)+w(i,j,k));
                wtemp(i,j,k)=(power(wave2,2)-power(wave1,2))/(zc(k+1)-zc(k));
                
                uave1=0.5*(u(i-1,j,k)+u(i-1,j,k+1));
                uave2=0.5*(u(i,j,k)+u(i,j,k+1));
                wave1=0.5*(w(i,j,k)+w(i-1,j,k));
                wave2=0.5*(w(i,j,k)+w(i+1,j,k));
                wtemp(i,j,k)=wtemp(i,j,k)+((uave2*wave2-uave1*wave1)/(xe(i)-xe(i-1)));
                
                vave1=0.5*(v(i,j-1,k)+v(i,j-1,k+1));
                vave2=0.5*(v(i,j,k)+v(i,j,k+1));
                wave1=0.5*(w(i,j,k)+w(i,j-1,k));
                wave2=0.5*(w(i,j,k)+w(i,j+1,k));
                wtemp(i,j,k)=wtemp(i,j,k)+((vave2*wave2-vave1*wave1)/(ye(j)-ye(j-1)));
                
                %calculation of diffusive w terms
                w1=(w(i+1,j,k)-w(i,j,k))/(xc(i+1)-xc(i));
                w2=(w(i,j,k)-w(i-1,j,k))/(xc(i)-xc(i-1));
                D2WDx2=(w1-w2)/(xe(i)-xe(i-1));
                
                w1=(w(i,j+1,k)-w(i,j,k))/(yc(j+1)-yc(j));
                w2=(w(i,j,k)-w(i,j-1,k))/(yc(j)-yc(j-1));
                D2WDy2=(w1-w2)/(ye(j)-ye(j-1));
                
                wtemp(i,j,k)=-wtemp(i,j,k)+(1/Re)*D2WDx2+(1/Re)*D2WDy2;
            end
        end
    end