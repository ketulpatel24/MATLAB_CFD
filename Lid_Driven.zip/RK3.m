function [uc,vc,wc,p1]=RK3(Lx,Ly,Lz,Nx,Ny,Nz,u,v,w,p,qu,qv,qw,dxc,dyc,dzc,dt,xe,xc,ye,yc,ze,zc,Re,C1,C2,C3)
     
    %start RK step
    dt1=C3*dt;
     
     %calculate temporal terms of u,v,w
    utemp=expu(Nx,Ny,Nz,u,v,w,xe,xc,ye,yc,ze,zc,Re);
    vtemp=expv(Nx,Ny,Nz,u,v,w,xe,xc,ye,yc,ze,zc,Re);
    wtemp=expw(Nx,Ny,Nz,u,v,w,xe,xc,ye,yc,ze,zc,Re);
    
    %update BC for temporal terms
    [utemp,vtemp,wtemp]=BC(Nx,Ny,Nz,utemp,vtemp,wtemp);
    
    %calculate qu,qv,qw
    for k=2:Nz+1
        for j=2:Ny+1
            for i=2:Nx
                qu(i,j,k)=C1*qu(i,j,k)+dt*utemp(i,j,k);
            end
        end
    end
    
    for k=2:Nz+1
        for j=2:Ny
            for i=2:Nx+1
                qv(i,j,k)=C1*qv(i,j,k)+dt*vtemp(i,j,k);
            end
        end
    end
    
    for k=2:Nz
        for j=2:Ny+1
            for i=2:Nx+1
                qw(i,j,k)=C1*qw(i,j,k)+dt*wtemp(i,j,k);
            end
        end
    end
          
    %calculate predicated velocities u,v,w using GS
    [up,vp,wp]=GS(Nx,Ny,Nz,dt1,dzc,u,v,w,qu,qv,qw,C2,Re);
    
    [up,vp,wp]=BC(Nx,Ny,Nz,up,vp,wp);
    
    %calculate pressure using MG
    p1=MG(Lx,Ly,Lz,Nx,Ny,Nz,up,vp,wp,p,dt1);
    
    %calculate corrected velocity
    [uc,vc,wc]=correct(Nx,Ny,Nz,up,vp,wp,dt1,p1,dxc,dyc,dzc);
    [uc,vc,wc]=BC(Nx,Ny,Nz,uc,vc,wc);
end