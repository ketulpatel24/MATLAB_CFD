function [up,vp,wp]=TDMA(Nx,Ny,Nz,dt,dzc,u,v,w,qu,qv,qw,C2,Re)
    %define diagonal vectors
    for i=2:Nx
        for j=2:Ny+1
            f(i,j,2)=1+(3*dt/(Re*power(dzc,2)));
            f(i,j,Nz+1)=1+(3*dt/(Re*power(dzc,2)));
            for k=3:Nz
                f(i,j,k)=1+(2*dt/(Re*power(dzc,2)));
            end
        end
    end
    
    %define subdiagonal vector
    for i=2:Nx
        for j=2:Ny+1
            for k=3:Nz+1
                e(i,j,k)=-dt/(Re*power(dzc,2));
            end
        end
    end
    
    %define superdiagonal vector
    for i=2:Nx
        for j=2:Ny+1
            for k=2:Nz
                g(i,j,k)=-dt/(Re*power(dzc,2));
            end
        end
    end
    
    %calculate RHS terms for u
    for i=2:Nx
        for j=2:Ny+1
            rtempu(i,j,Nz+1)=u(i,j,Nz+1)+C2*qu(i,j,Nz+1)+2*dt/(Re*power(dzc,2));
            for k=2:Nz
                rtempu(i,j,k)=u(i,j,k)+C2*qu(i,j,k);
            end
        end
    end
    
    %forward elimination
    for i=2:Nx
        for j=2:Ny+1
            for k=3:Nz+1
                factor=e(i,j,k)/f(i,j,k-1);
                f(i,j,k)=f(i,j,k)-factor*g(i,j,k-1);
                rtempu(i,j,k)=rtempu(i,j,k)-factor*rtempu(i,j,k-1);
            end
        end
    end
    %back substitution
    for i=2:Nx
        for j=2:Ny+1
            up(i,j,Nz+1)=rtempu(i,j,Nz+1)/f(i,j,Nz+1);
            for k=Nz:2
                up(i,j,k)=(rtempu(i,j,k)-g(i,j,k)*up(i,j,k+1))/f(i,j,k);
            end
        end
    end
    
    %calculate vp using thomas algorithm
    %define diagonal vectors
    for i=2:Nx+1
        for j=2:Ny
            f(i,j,2)=1+(3*dt/(Re*power(dzc,2)));
            f(i,j,Nz+1)=1+(3*dt/(Re*power(dzc,2)));
            for k=3:Nz
                f(i,j,k)=1+(2*dt/(Re*power(dzc,2)));
            end
        end
    end
    
    %define subdiagonal vector
    for i=2:Nx+1
        for j=2:Ny
            for k=3:Nz+1
                e(i,j,k)=-dt/(Re*power(dzc,2));
            end
        end
    end
    
    %define superdiagonal vector
    for i=2:Nx+1
        for j=2:Ny
            for k=2:Nz
                g(i,j,k)=-dt/(Re*power(dzc,2));
            end
        end
    end
    
    %calculate RHS terms for v
    for i=2:Nx+1
        for j=2:Ny
            for k=2:Nz+1
                rtempv(i,j,k)=v(i,j,k)+C2*qv(i,j,k);
            end
        end
    end
    
    %forward elimination
    for i=2:Nx+1
        for j=2:Ny
            for k=3:Nz+1
                factor=e(i,j,k)/f(i,j,k-1);
                f(i,j,k)=f(i,j,k)-factor*g(i,j,k-1);
                rtempv(i,j,k)=rtempv(i,j,k)-factor*rtempv(i,j,k-1);
            end
        end
    end
    %back substitution
    for i=2:Nx+1
        for j=2:Ny
            vp(i,j,Nz+1)=rtempv(i,j,Nz+1)/f(i,j,Nz+1);
            for k=Nz:2
                vp(i,j,k)=(rtempv(i,j,k)-g(i,j,k)*vp(i,j,k+1))/f(i,j,k);
            end
        end
    end
    
    %calculate wp using thomas algorithm
    %define diagonal vectors
    for i=2:Nx+1
        for j=2:Ny+1
            for k=2:Nz
                f(i,j,k)=1+(2*dt/(Re*power(dzc,2)));
            end
        end
    end
    
    %define subdiagonal vector
    for i=2:Nx+1
        for j=2:Ny+1
            for k=3:Nz
                e(i,j,k)=-dt/(Re*power(dzc,2));
            end
        end
    end
    
    %define superdiagonal vector
    for i=2:Nx+1
        for j=2:Ny+1
            for k=2:Nz-1
                g(i,j,k)=-dt/(Re*power(dzc,2));
            end
        end
    end
    
    %calculate RHS terms for w
    for i=2:Nx+1
        for j=2:Ny+1
            for k=2:Nz
                rtempw(i,j,k)=w(i,j,k)+C2*qw(i,j,k);
            end
        end
    end
    
    %forward elimination
    for i=2:Nx+1
        for j=2:Ny+1
            for k=3:Nz
                factor=e(i,j,k)/f(i,j,k-1);
                f(i,j,k)=f(i,j,k)-factor*g(i,j,k-1);
                rtempw(i,j,k)=rtempw(i,j,k)-factor*rtempw(i,j,k-1);
            end
        end
    end
    %back substitution
    for i=2:Nx+1
        for j=2:Ny+1
            wp(i,j,Nz)=rtempw(i,j,Nz)/f(i,j,Nz);
            for k=Nz-1:2
                wp(i,j,k)=(rtempw(i,j,k)-g(i,j,k)*wp(i,j,k+1))/f(i,j,k);
            end
        end
    end