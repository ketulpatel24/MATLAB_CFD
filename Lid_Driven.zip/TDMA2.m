function [up,vp,wp]=TDMA2(Nx,Ny,Nz,dt,dzc,u,v,w,qu,qv,qw,C2,Re)
    
    
    %define diagonal and subdiagonal vectors
    for k=2:Nz+1
        for j=2:Ny+1
            for i=2:Nx
                b(i,j,k)=1+(2*dt/(Re*power(dzc,2)));
            end
        end
    end
    
    for k=2:Nz+1
        for j=2:Ny+1
            for i=2:Nx
                a(i,j,k)=-dt/(Re*power(dzc,2));
            end
        end
    end
    
    for k=2:Nz+1
        for j=2:Ny+1
            for i=2:Nx
                c(i,j,k)=-dt/(Re*power(dzc,2));
            end
        end
    end
    
    %calculate RHS terms for u
    for k=2:Nz+1
        for j=2:Ny+1
            for i=2:Nx
                rtempu(i,j,k)=u(i,j,k)+C2*qu(i,j,k);
            end
        end
    end
    
    for i=2:Nx
        for j=2:Ny+1
            A(i,j,2)=c(i,j,2)/(b(i,j,2)-a(i,j,2));
            B(i,j,2)=rtempu(i,j,2)/(b(i,j,2)-a(i,j,2));
        end
    end
    
    for i=2:Nx
        for j=2:Ny+1
            for k=3:Nz
                A(i,j,k)=c(i,j,k)/(b(i,j,k)-a(i,j,k)*A(i,j,k-1));
                B(i,j,k)=(a(i,j,k)*B(i,j,k-1)+rtempu(i,j,k))/(b(i,j,k)-a(i,j,k)*A(i,j,k-1));
                
            end
        end
    end
    
    for i=2:Nx
        for j=2:Ny+1
            B(i,j,Nz+1)=(a(i,j,Nz+1)*B(i,j,Nz)+rtempu(i,j,Nz+1)-2*c(i,j,Nz+1))/(b(i,j,Nz+1)-c(i,j,Nz+1)-a(i,j,Nz+1)*A(i,j,Nz));
        end
    end
    
    for i=2:Nx
        for j=2:Ny+1
            up(i,j,Nz+1)=B(i,j,Nz+1);
            for k=Nz:2
                up(i,j,k)=A(i,j,k)*up(i,j,k+1)+B(i,j,k);
            end
        end
    end
    %end of calculation of up
    
    %define diagonal and subdiagonal vectors
    for k=2:Nz+1
        for j=2:Ny
            for i=2:Nx+1
                b(i,j,k)=1+(2*dt/(Re*power(dzc,2)));
            end
        end
    end
    
    for k=2:Nz+1
        for j=2:Ny
            for i=2:Nx+1
                a(i,j,k)=-dt/(Re*power(dzc,2));
            end
        end
    end
    
    for k=2:Nz+1
        for j=2:Ny
            for i=2:Nx+1
                c(i,j,k)=-dt/(Re*power(dzc,2));
            end
        end
    end
    
    %calculate RHS terms for v
    for k=2:Nz+1
        for j=2:Ny
            for i=2:Nx+1
                rtempv(i,j,k)=v(i,j,k)+C2*qv(i,j,k);
            end
        end
    end
    
    for i=2:Nx+1
        for j=2:Ny
            A(i,j,2)=c(i,j,2)/(b(i,j,2)-a(i,j,2));
            B(i,j,2)=rtempv(i,j,2)/(b(i,j,2)-a(i,j,2));
        end
    end
    
    for i=2:Nx+1
        for j=2:Ny
            for k=3:Nz
                A(i,j,k)=c(i,j,k)/(b(i,j,k)-a(i,j,k)*A(i,j,k-1));
                B(i,j,k)=(a(i,j,k)*B(i,j,k-1)+rtempv(i,j,k))/(b(i,j,k)-a(i,j,k)*A(i,j,k-1));
            end
        end
    end
    
    for i=2:Nx+1
        for j=2:Ny
            B(i,j,Nz+1)=(a(i,j,Nz+1)*B(i,j,Nz)+rtempv(i,j,Nz+1))/(b(i,j,Nz+1)-c(i,j,Nz+1)-a(i,j,Nz+1)*A(i,j,Nz));
        end
    end
    
    for i=2:Nx+1
        for j=2:Ny
            vp(i,j,Nz+1)=B(i,j,Nz+1);
            for k=Nz:2
                vp(i,j,k)=A(i,j,k)*vp(i,j,k+1)+B(i,j,k);
            end
        end
    end
    %end of calculation of vp
    
    
    %define diagonal and subdiagonal vectors
    for k=2:Nz
        for j=2:Ny+1
            for i=2:Nx+1
                b(i,j,k)=1+(2*dt/(Re*power(dzc,2)));
            end
        end
    end
    
    for k=2:Nz
        for j=2:Ny+1
            for i=2:Nx+1
                a(i,j,k)=-dt/(Re*power(dzc,2));
            end
        end
    end
    
    for k=2:Nz
        for j=2:Ny+1
            for i=2:Nx+1
                c(i,j,k)=-dt/(Re*power(dzc,2));
            end
        end
    end
    
    %calculate RHS terms for w
    for k=2:Nz
        for j=2:Ny+1
            for i=2:Nx+1
                rtempw(i,j,k)=w(i,j,k)+C2*qw(i,j,k);
            end
        end
    end
    
    for i=2:Nx+1
        for j=2:Ny+1
            A(i,j,2)=c(i,j,2)/(b(i,j,2));
            B(i,j,2)=rtempw(i,j,2)/(b(i,j,2));
        end
    end
    
    for i=2:Nx+1
        for j=2:Ny+1
            for k=3:Nz-1
                A(i,j,k)=c(i,j,k)/(b(i,j,k)-a(i,j,k)*A(i,j,k-1));
                B(i,j,k)=(a(i,j,k)*B(i,j,k-1)+rtempw(i,j,1))/(b(i,j,k)-a(i,j,k)*A(i,j,k-1));
            end
        end
    end
    
    for i=2:Nx+1
        for j=2:Ny+1
            B(i,j,Nz)=(a(i,j,Nz)*B(i,j,Nz-1)+rtempw(i,j,Nz))/(b(i,j,Nz)-a(i,j,Nz)*A(i,j,Nz-1));
        end
    end
    
    for i=2:Nx+1
        for j=2:Ny+1
            wp(i,j,Nz)=B(i,j,Nz);
            for k=Nz-1:2
                wp(i,j,k)=A(i,j,k)*wp(i,j,k+1)+B(i,j,k);
            end
        end
    end
    %end of calculation of wp
end