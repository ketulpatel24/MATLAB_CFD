clc
clear

%define x,y,z length
Lx=1;
Ly=1;
Lz=1;
Re=400;

%define number of grid in each direction
Nx=16;  Ny=16;  Nz=16;

%define time step size & time
dt=0.05;
time=10;
n=time/dt;

%calculate dxe,dye,dze & dxc,dyc,dzc
dxe=Lx/Nx;  dye=Ly/Ny;  dze=Lz/Nz;
dxc=Lx/Nx;  dyc=Ly/Ny;  dzc=Lz/Nz;

%define xe,ye,ze at each grid edge
xe(1)=0;    ye(1)=0;    ze(1)=0;
xe(Nx+2)=Lx+dxe;    ye(Ny+2)=Ly+dye;    ze(Nz+2)=Lz+dze;

for i=2:Nx+1
    xe(i)=xe(i-1)+dxe;
end

for j=2:Ny+1
    ye(j)=ye(j-1)+dye;
end

for k=2:Nz+1
    ze(k)=ze(k-1)+dze;
end

%define xc,yc,zc at each grid edge
xc(1)=-dxc/2;    yc(1)=-dyc/2;    zc(1)=-dzc/2;
xc(Nx+2)=Lx+(dxc/2);    yc(Ny+2)=Ly+(dyc/2);    zc(Nz+2)=Lz+(dzc/2);

for i=2:Nx+1
    xc(i)=xc(i-1)+dxc;
end

for j=2:Ny+1
    yc(j)=yc(j-1)+dyc;
end

for k=2:Nz+1
    zc(k)=zc(k-1)+dzc;
end

%Initialize u,v,w,p
for k=1:Nz+2
    for j=1:Ny+2
        for i=1:Nx+1
            u(i,j,k)=0;
        end
    end
end

for k=1:Nz+2
    for j=1:Ny+1
        for i=1:Nx+2
            v(i,j,k)=0;
        end
    end
end

for k=1:Nz+1
    for j=1:Ny+2
        for i=1:Nx+2
            w(i,j,k)=0;
        end
    end
end

for k=1:Nz+2
    for j=1:Ny+2
        for i=1:Nx+2
            p(i,j,k)=0;
        end
    end
end

%update BC's
[u,v,w]=BC(Nx,Ny,Nz,u,v,w);

for iter=1:600
   
    for k=1:Nz+2
        for j=1:Ny+2
            for i=1:Nx+1
                qu(i,j,k)=0;
            end
        end
    end
    
    for k=1:Nz+2
        for j=1:Ny+1
            for i=1:Nx+2
                qv(i,j,k)=0;
            end
        end
    end
    
    for k=1:Nz+1
        for j=1:Ny+2
            for i=1:Nx+2
                qw(i,j,k)=0;
            end
        end
    end
    
    C1=0;   C2=(1/3);   C3=(1/3);
    [u1,v1,w1,p1]=RK3(Lx,Ly,Lz,Nx,Ny,Nz,u,v,w,p,qu,qv,qw,dxc,dyc,dzc,dt,xe,xc,ye,yc,ze,zc,Re,C1,C2,C3);
    
    C1=-5/9;   C2=(15/16);   C3=(5/12);
    [u2,v2,w2,p2]=RK3(Lx,Ly,Lz,Nx,Ny,Nz,u1,v1,w1,p1,qu,qv,qw,dxc,dyc,dzc,dt,xe,xc,ye,yc,ze,zc,Re,C1,C2,C3);
    
    C1=-153/128;   C2=(8/15);   C3=(1/4);
    [u,v,w,p3]=RK3(Lx,Ly,Lz,Nx,Ny,Nz,u2,v2,w2,p2,qu,qv,qw,dxc,dyc,dzc,dt,xe,xc,ye,yc,ze,zc,Re,C1,C2,C3);
    
    umax = max([max(u(:)), max(v(:)), max(w(:))]);
    cfl = umax*dt/dxe;
    
    if cfl > 1.2
        c = 1.2;
        dtx = c*dxe/max(u(:));
        dty = c*dye/max(v(:));
        dtz = c*dze/max(w(:));     
        dt = min([dtx, dty, dtz]);
    end
    c = 1.2;
    dtx = c*dxe/max(u(:));
    dty = c*dye/max(v(:));
    dtz = c*dze/max(w(:));
%     
%     dt = min([dtx, dty, dtz]);
    disp(iter)       
end
%calculate velocities at cell centers
for k=2:Nz+1
    for j=2:Ny+1
        for i=2:Nx+1
            ur(i,j,k)=(u(i,j,k)+u(i-1,j,k))/2;
            vr(i,j,k)=(v(i,j,k)+v(i,j-1,k))/2;
            wr(i,j,k)=(w(i,j,k)+w(i,j,k-1))/2;
        end
    end
end

%update boundary conditions
for k=1:Nz+2
    for j=1:Ny+2
        for i=1:Nx+2
            ur(1,j,k)=ur(2,j,k);
            ur(Nx+2,j,k)=ur(Nx+1,j,k);
            ur(i,1,k)=ur(i,2,k);
            ur(i,Ny+2,k)=ur(i,Ny+1,k);
            ur(i,j,1)=ur(i,j,2);
            ur(i,j,Nz+2)=ur(i,j,Nz+1);
            
            vr(1,j,k)=vr(2,j,k);
            vr(Nx+2,j,k)=vr(Nx+1,j,k);
            vr(i,1,k)=vr(i,2,k);
            vr(i,Ny+2,k)=vr(i,Ny+1,k);
            vr(i,j,1)=vr(i,j,2);
            vr(i,j,Nz+2)=vr(i,j,Nz+1);
            
            wr(1,j,k)=wr(2,j,k);
            wr(Nx+2,j,k)=wr(Nx+1,j,k);
            wr(i,1,k)=wr(i,2,k);
            wr(i,Ny+2,k)=wr(i,Ny+1,k);
            wr(i,j,1)=wr(i,j,2);
            wr(i,j,Nz+2)=wr(i,j,Nz+1);
        end
    end
end

    for k=1:Nz+2
        for i=1:Nx+2
                U(k,i)=sqrt(power(ur(i,Ny/2,k),2)+power(wr(i,Ny/2,k),2));
                Ur(k,i)=ur(i,Ny/2,k);
                Wr(k,i)=wr(i,Ny/2,k);
%               U(i,k)=abs(u(i,16,k));
        end
    end
    
    figure(1)
    contourf(xc,zc,U)
    colorbar
    title("velocity Re=400 (Nx=Nz=Ny=16)")
    axis([0 1 0 1])
    xlabel("X")
    ylabel("Z")
    
    figure(2)
    quiver(xc,zc,Ur,Wr,2,"color","b")
    hold on
%     contour(xc,zc,U)
%     colorbar
    title("streamline Re=400 (Nx=Nz=Ny=16)")
    axis([0 1 0 1])
    xlabel("X")
    ylabel("Z")