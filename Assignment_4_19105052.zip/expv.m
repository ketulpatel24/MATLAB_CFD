function [vtemp]=expv(Nx,Ny,Nz,u,v,w,xe,xc,ye,yc,ze,zc,Re)
    for k=2:Nz+1
        for j=2:Ny
            for i=2:Nx+1
                %calculation of convective v terms
                vave1=0.5*(v(i,j,k)+v(i,j-1,k));
                vave2=0.5*(v(i,j+1,k)+v(i,j,k));
                vtemp(i,j,k)=(power(vave2,2)-power(vave1,2))/(yc(j+1)-yc(j));
                
                uave1=0.5*(u(i-1,j,k)+u(i-1,j+1,k));
                uave2=0.5*(u(i,j,k)+u(i,j+1,k));
                vave1=0.5*(v(i,j,k)+v(i-1,j,k));
                vave2=0.5*(v(i,j,k)+v(i+1,j,k));
                vtemp(i,j,k)=vtemp(i,j,k)+((uave2*vave2-uave1*vave1)/(xe(i)-xe(i-1)));
                
                vave1=0.5*(v(i,j,k)+v(i,j,k-1));
                vave2=0.5*(v(i,j,k)+v(i,j,k+1));
                wave1=0.5*(w(i,j,k-1)+w(i,j+1,k-1));
                wave2=0.5*(w(i,j,k)+w(i,j+1,k));
                vtemp(i,j,k)=vtemp(i,j,k)+((vave2*wave2-vave1*wave1)/(ze(k)-ze(k-1)));
                
                %calculation of diffusive v terms
                v1=(v(i+1,j,k)-v(i,j,k))/(xc(i+1)-xc(i));
                v2=(v(i,j,k)-v(i-1,j,k))/(xc(i)-xc(i-1));
                D2VDx2=(v1-v2)/(xe(i)-xe(i-1));
                
                v1=(v(i,j+1,k)-v(i,j,k))/(ye(j+1)-ye(j));
                v2=(v(i,j,k)-v(i,j-1,k))/(ye(j)-ye(j-1));
                D2VDy2=(v1-v2)/(yc(j+1)-yc(j));
                
                vtemp(i,j,k)=-vtemp(i,j,k)+(1/Re)*D2VDx2+(1/Re)*D2VDy2;
            end
        end
    end