function [utemp]=expu(Nx,Ny,Nz,u,v,w,xe,xc,ye,yc,ze,zc,Re)
    for k=2:Nz+1
        for j=2:Ny+1
            for i=2:Nx
                %calculation of convective u terms
                uave1=0.5*(u(i,j,k)+u(i-1,j,k));
                uave2=0.5*(u(i+1,j,k)+u(i,j,k));
                utemp(i,j,k)=(power(uave2,2)-power(uave1,2))/(xc(i+1)-xc(i));
                
                uave1=0.5*(u(i,j,k)+u(i,j-1,k));
                uave2=0.5*(u(i,j,k)+u(i,j+1,k));
                vave1=0.5*(v(i,j-1,k)+v(i+1,j-1,k));
                vave2=0.5*(v(i,j,k)+v(i+1,j,k));
                utemp(i,j,k)=utemp(i,j,k)+((uave2*vave2-uave1*vave1)/(ye(j)-ye(j-1)));
                
                uave1=0.5*(u(i,j,k)+u(i,j,k-1));
                uave2=0.5*(u(i,j,k)+u(i,j,k+1));
                wave1=0.5*(w(i,j,k-1)+w(i+1,j,k-1));
                wave2=0.5*(w(i,j,k)+w(i+1,j,k));
                utemp(i,j,k)=utemp(i,j,k)+((uave2*wave2-uave1*wave1)/(ze(k)-ze(k-1)));
                
                %calculation of diffusive u terms
                u1=(u(i+1,j,k)-u(i,j,k))/(xe(i+1)-xe(i));
                u2=(u(i,j,k)-u(i-1,j,k))/(xe(i)-xe(i-1));
                D2UDx2=(u1-u2)/(xc(i+1)-xc(i));
                
                u1=(u(i,j+1,k)-u(i,j,k))/(yc(j+1)-yc(j));
                u2=(u(i,j,k)-u(i,j-1,k))/(yc(j)-yc(j-1));
                D2UDy2=(u1-u2)/(ye(j)-ye(j-1));
                
                utemp(i,j,k)=-utemp(i,j,k)+(1/Re)*D2UDx2+(1/Re)*D2UDy2;
            end
        end
    end