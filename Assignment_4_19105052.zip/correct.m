function [uc,vc,wc]=correct(Nx,Ny,Nz,up,vp,wp,dt,p,dxc,dyc,dzc)
    for k=2:Nz+1
        for j=2:Ny+1
            for i=2:Nx
                uc(i,j,k)=up(i,j,k)-dt*((p(i+1,j,k)-p(i,j,k))/dxc);
            end
        end
    end
    
    for k=2:Nz+1
        for j=2:Ny
            for i=2:Nx+1
                vc(i,j,k)=vp(i,j,k)-dt*((p(i,j+1,k)-p(i,j,k))/dyc);
            end
        end
    end
    
    for k=2:Nz
        for j=2:Ny+1
            for i=2:Nx+1
                wc(i,j,k)=wp(i,j,k)-dt*((p(i,j,k+1)-p(i,j,k))/dzc);
            end
        end
    end
    
end