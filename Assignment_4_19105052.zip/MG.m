function [pr]=MG(Lx,Ly,Lz,Nx,Ny,Nz,up,vp,wp,p,dt)
    A=[log2(Nx),log2(Ny),log2(Nz)];
    level=min(A);   %calculate maximum possible level
    presweep=10;postsweep=10;
    
    %calculate m,n,l values at each level
    for i=1:level
        m(i)=Nx/power(2,i-1);n(i)=Ny/power(2,i-1);l(i)=Nz/power(2,i-1);
    end
    
    %calculate dx,dy,dz values at each level
    for i=1:level
        dx(i)=Lx/m(i);dy(i)=Ly/n(i);dz(i)=Lz/l(i);
    end
    
    %define p for each level
    for N=1:level
        for i=1:m(N)+2
            for j=1:n(N)+2
                for k=1:l(N)+2
                    phi(1,i,j,k)=0;
                    phi0(1,i,j,k)=0;
                    %phip(N,i,j,k)=0;
                    %res(N,i,j,k)=0;
                end
            end
        end
    end
    
    %define coefficients for each level
    for N=1:level
        for i=1:m(N)+2
            for j=1:n(N)+2
                for k=1:l(N)+2
                    ae(N,i,j,k)=1/power(dx(N),2);aw(N,i,j,k)=1/power(dx(N),2);
                    an(N,i,j,k)=1/power(dy(N),2);as(N,i,j,k)=1/power(dy(N),2);
                    at(N,i,j,k)=1/power(dz(N),2);ab(N,i,j,k)=1/power(dz(N),2);
                    ap(N,i,j,k)=-ae(N,i,j,k)-aw(N,i,j,k)-an(N,i,j,k)-as(N,i,j,k)-at(N,i,j,k)-ab(N,i,j,k);
                end
            end
        end
    end
    
    %calculate x,y,z values for each level
    for N=1:level
        x(N,1)=-dx(N)/2;    x(N,m(N)+2)=1+(dx(N)/2);  %define Ghost Points
        y(N,1)=-dy(N)/2;    y(N,n(N)+2)=1+(dy(N)/2);
        z(N,1)=-dz(N)/2;    z(N,l(N)+2)=1+(dz(N)/2);
        for i=2:m(N)+1
            x(N,i)=x(N,i-1)+dx(N);
        end
        for j=2:n(N)+1
            y(N,j)=y(N,j-1)+dy(N);
        end
        for k=2:l(N)+1
            z(N,k)=z(N,k-1)+dz(N);
        end
    end
    
    %calculate RHS term for first level
    for k=2:l(1)+1
        for j=2:n(1)+1
            for i=2:m(1)+1
                b(i,j,k)=(1/dt)*(((up(i,j,k)-up(i-1,j,k))/dx(1))+((vp(i,j,k)-vp(i,j-1,k))/dy(1))+((wp(i,j,k)-wp(i,j,k-1))/dz(1)));
            end
        end
    end
    
        
    L2norm=1.0;count=0;
tolerance=0.0000001;
while (L2norm>tolerance) && (count<600)
    %storing phi values in phi0 at level 1
    for k=1:l(1)+2
        for j=1:n(1)+2
            for i=1:m(1)+2
                phi0(1,i,j,k)=phi(1,i,j,k);
            end
        end
    end
    
    %gauss seidel loop for first level
    for t=1:presweep
    %calculation of phi
        for k=2:l(1)+1
            for j=2:n(1)+1
                for i=2:m(1)+1                 
                    phi(1,i,j,k)=(b(i,j,k)-ae(1,i,j,k)*phi(1,i+1,j,k)-aw(1,i,j,k)*phi(1,i-1,j,k)-an(1,i,j,k)*phi(1,i,j+1,k) ...
                        -as(1,i,j,k)*phi(1,i,j-1,k)-at(1,i,j,k)*phi(1,i,j,k+1)-ab(1,i,j,k)*phi(1,i,j,k-1))/ap(1,i,j,k);

                end
            end
        end
    %Update boundary and Periodic condition
        for k=1:l(1)+2
            for j=1:n(1)+2
                for i=1:m(1)+2
                    phi(1,m(1)+2,j,k)=phi(1,m(1)+1,j,k);
                    phi(1,1,j,k)=phi(1,2,j,k);
                    phi(1,i,j,1)=phi(1,i,j,2);
                    phi(1,i,j,l(1)+2)=phi(1,i,j,l(1)+1);
                
                    phi(1,i,n(1)+2,k)=phi(1,i,2,k);
                    phi(1,i,1,k)=phi(1,i,n(1)+1,k);
                end
            end
        end
    end
    
    %calculation of residual at 1st level
    for k=2:l(1)+1
        for j=2:n(1)+1
            for i=2:m(1)+1
                res(1,i,j,k)=b(i,j,k)-(ae(1,i,j,k)*phi(1,i+1,j,k)+aw(1,i,j,k)*phi(1,i-1,j,k)+an(1,i,j,k)*phi(1,i,j+1,k)+ ...
                    as(1,i,j,k)*phi(1,i,j-1,k)+at(1,i,j,k)*phi(1,i,j,k+1)+ab(1,i,j,k)*phi(1,i,j,k-1)+ap(1,i,j,k)*phi(1,i,j,k));
            end
        end
    end
    %update residual at boundary
    for k=1:l(1)+2
        for j=1:n(1)+2
            for i=1:m(1)+2
                res(1,m(1)+2,j,k)=-res(1,m(1)+1,j,k);
                res(1,1,j,k)=-res(1,2,j,k);
                res(1,i,j,1)=-res(1,i,j,2);
                res(1,i,j,l(1)+2)=-res(1,i,j,l(1)+1);
                res(1,i,1,k)=-res(1,i,2,k);
                res(1,i,n(1)+2,k)=-res(1,i,n(1)+1,k);
            end
        end
    end
    
    for N=2:level
        
        %restrict residual of current level to next level RHS
        for k=2:l(N)+1
            for j=2:n(N)+1
                for i=2:m(N)+1
                    p=2*i-2;q=2*j-2;r=2*k-2;
                    rhs(N,i,j,k)=0.125*(res(N-1,p,q,r)+res(N-1,p+1,q,r)+res(N-1,p,q+1,r)+res(N-1,p+1,q+1,r)+res(N-1,p,q,r+1)+ ...
                        res(N-1,p+1,q,r+1)+res(N-1,p,q+1,r+1)+res(N-1,p+1,q+1,r+1));
                end
            end
        end
        
        %update RHS values at boundary
        for k=1:l(N)+2
            for j=1:n(N)+2
                for i=1:m(N)+2
                    rhs(N,m(N)+2,j,k)=-rhs(N,m(N)+1,j,k);
                    rhs(N,1,j,k)=-rhs(N,2,j,k);
                    rhs(N,i,j,1)=-rhs(N,i,j,2);
                    rhs(N,i,j,l(N)+2)=-rhs(N,i,j,l(N)+1);
                    rhs(N,i,1,k)=-rhs(N,i,2,k);
                    rhs(N,i,n(N)+2,k)=-rhs(N,i,n(N)+1,k);
                end
            end
        end
        
        %Initialize phi as error for next level equal to zero
        for k=1:l(N)+2
            for j=1:n(N)+2
                for i=1:m(N)+2
                    phi(N,i,j,k)=0;
                end
            end
        end
        
        
        %GS loop for each level except 1st level
        for t=1:presweep
        %calculation of phi at each level except 1st level
            for k=2:l(N)+1
                for j=2:n(N)+1
                    for i=2:m(N)+1
                        phi(N,i,j,k)=(rhs(N,i,j,k)-ae(N,i,j,k)*phi(N,i+1,j,k)-aw(N,i,j,k)*phi(N,i-1,j,k)-an(N,i,j,k)*phi(N,i,j+1,k)- ...
                            as(N,i,j,k)*phi(N,i,j-1,k)-at(N,i,j,k)*phi(N,i,j,k+1)-ab(N,i,j,k)*phi(N,i,j,k-1))/ap(N,i,j,k);
                    end
                end
            end
            
            %update boundary condition at each level
            for k=1:l(N)+2
                for j=1:n(N)+2
                    for i=1:m(N)+2
                        phi(N,m(N)+2,j,k)=-phi(N,m(N)+1,j,k);
                        phi(N,1,j,k)=-phi(N,2,j,k);
                        phi(N,i,j,1)=-phi(N,i,j,2);
                        phi(N,i,j,l(N)+2)=-phi(N,i,j,l(N)+1);
                        phi(N,i,n(N)+2,k)=-phi(N,i,n(N)+1,k);
                        phi(N,i,1,k)=-phi(N,i,2,k);
                    end
                end
            end
        end
        %calculation of residual at each level
        for k=2:l(N)+1
            for j=2:n(N)+1
                for i=2:m(N)+1
                    res(N,i,j,k)=rhs(N,i,j,k)-(ae(N,i,j,k)*phi(N,i+1,j,k)+aw(N,i,j,k)*phi(N,i-1,j,k)+an(N,i,j,k)*phi(N,i,j+1,k)+ ...
                    as(N,i,j,k)*phi(N,i,j-1,k)+at(N,i,j,k)*phi(N,i,j,k+1)+ab(N,i,j,k)*phi(N,i,j,k-1)+ap(N,i,j,k)*phi(N,i,j,k));
                end
            end
        end
        
        %update residual at boundary
        for k=1:l(N)+2
            for j=1:n(N)+2
                for i=1:m(N)+2
                    res(N,m(N)+2,j,k)=-res(N,m(N)+1,j,k);
                    res(N,1,j,k)=-res(N,2,j,k);
                    res(N,i,j,1)=-res(N,i,j,2);
                    res(N,i,j,l(N)+2)=-res(N,i,j,l(N)+1);
                    res(N,i,1,k)=-res(N,i,2,k);
                    res(N,i,n(N)+2,k)=-res(N,i,n(N)+1,k);
                end
            end
        end
    end
       
    for N=level:2
        %prolongate phi into phi(N)(N-1)
         for k=2:l(N)+1
             for j=2:n(N)+1
                 for i=2:m(N)+1
                     p=2*i-1;q=2*j-1;r=2*k-1;
                        phip(N,p,q,r)=(1/64)*(27*phi(N,i,j,k)+9*phi(N,i+1,j,k)+9*phi(N,i,j+1,k)+9*phi(N,i,j,k+1)+3*phi(N,i+1,j+1,k)+ ...
                            3*phi(N,i+1,j,k+1)+3*phi(N,i,j+1,k+1)+phi(N,i+1,j+1,k+1));
                        phip(N,p+1,q,r)=(1/64)*(9*phi(N,i,j,k)+27*phi(N,i+1,j,k)+3*phi(N,i,j+1,k)+3*phi(N,i,j,k+1)+9*phi(N,i+1,j+1,k)+ ...
                            9*phi(N,i+1,j,k+1)+phi(N,i,j+1,k+1)+3*phi(N,i+1,j+1,k+1));
                        phip(N,p,q+1,r)=(1/64)*(9*phi(N,i,j,k)+3*phi(N,i+1,j,k)+27*phi(N,i,j+1,k)+3*phi(N,i,j,k+1)+9*phi(N,i+1,j+1,k)+ ...
                            phi(N,i+1,j,k+1)+9*phi(N,i,j+1,k+1)+3*phi(N,i+1,j+1,k+1));
                        phip(N,p,q,r+1)=(1/64)*(9*phi(N,i,j,k)+3*phi(N,i+1,j,k)+3*phi(N,i,j+1,k)+27*phi(N,i,j,k+1)+phi(N,i+1,j+1,k)+ ...
                            9*phi(N,i+1,j,k+1)+9*phi(N,i,j+1,k+1)+3*phi(N,i+1,j+1,k+1));
                        phip(N,p+1,q,r+1)=(1/64)*(3*phi(N,i,j,k)+9*phi(N,i+1,j,k)+phi(N,i,j+1,k)+9*phi(N,i,j,k+1)+3*phi(N,i+1,j+1,k)+ ...
                            27*phi(N,i+1,j,k+1)+3*phi(N,i,j+1,k+1)+9*phi(N,i+1,j+1,k+1));
                        phip(N,p,q+1,r+1)=(1/64)*(3*phi(N,i,j,k)+phi(N,i+1,j,k)+9*phi(N,i,j+1,k)+9*phi(N,i,j,k+1)+9*phi(N,i+1,j+1,k)+ ...
                            3*phi(N,i+1,j,k+1)+27*phi(N,i,j+1,k+1)+3*phi(N,i+1,j+1,k+1));
                        phip(N,p+1,q+1,r)=(1/64)*(3*phi(N,i,j,k)+9*phi(N,i+1,j,k)+9*phi(N,i,j+1,k)+phi(N,i,j,k+1)+27*phi(N,i+1,j+1,k)+ ...
                            3*phi(N,i+1,j,k+1)+3*phi(N,i,j+1,k+1)+9*phi(N,i+1,j+1,k+1));
                        phip(N,p+1,q+1,r+1)=(1/64)*(phi(N,i,j,k)+3*phi(N,i+1,j,k)+3*phi(N,i,j+1,k)+3*phi(N,i,j,k+1)+9*phi(N,i+1,j+1,k)+ ...
                            9*phi(N,i+1,j,k+1)+9*phi(N,i,j+1,k+1)+27*phi(N,i+1,j+1,k+1));
                 end
             end
         end
         
         for k=1:l(N)+2
            for j=1:n(N)+2
                for i=1:m(N)+2
                    phip(N,m(N)+2,j,k)=-phip(N,m(N)+1,j,k);
                    phip(N,1,j,k)=-phip(N,2,j,k);
                    phip(N,i,j,1)=-phip(N,i,j,2);
                    phip(N,i,j,l(N)+2)=-phip(N,i,j,l(N)+1);
                    phip(N,i,1,k)=-phip(N,i,2,k);
                    phip(N,i,n(N)+2,k)=-phip(N,i,n(N)+1,k);
                end
            end
        end
         %update value of phi1
        for k=1:l(N-1)+2
            for j=1:n(N-1)+2
                for i=1:m(N-1)+2
                    phi(N-1,i,j,k)=phi(N-1,i,j,k)+phip(N,i,j,k);
                end
            end
        end
        
        %GS loop for previous level
        for t=1:postsweep
        %calculation of phi at previous level
            for k=2:l(N-1)+1
                for j=2:n(N-1)+1
                    for i=2:m(N-1)+1
                        phi(N-1,i,j,k)=(rhs(N-1,i,j,k)-ae(N-1,i,j,k)*phi(N-1,i+1,j,k)-aw(N-1,i,j,k)*phi(N-1,i-1,j,k)-an(N-1,i,j,k)*phi(N-1,i,j+1,k)- ...
                            as(N-1,i,j,k)*phi(N-1,i,j-1,k)-at(N-1,i,j,k)*phi(N-1,i,j,k+1)-ab(N-1,i,j,k)*phi(N-1,i,j,k-1))/ap(N-1,i,j,k);
                    end
                end
            end
    
            %update boundary condition
            for k=1:l(N-1)+2
                for j=1:n(N-1)+2
                    for i=1:m(N-1)+2
                        phi(N-1,m(N-1)+2,j,k)=-phi(N-1,m(N-1)+1,j,k);
                        phi(N-1,1,j,k)=-phi(N-1,2,j,k);
                        phi(N-1,i,j,1)=-phi(N-1,i,j,2);
                        phi(N-1,i,j,l(N-1)+2)=-phi(N-1,i,j,l(N-1)+1);
                        phi(N-1,i,n(N-1)+2,k)=-phi(N-1,i,n(N-1)+1,k);
                        phi(N-1,i,1,k)=-phi(N-1,i,2,k);
                    end
                end
            end
        end

    end
    
    %gauss seidel loop for first level
    for t=1:postsweep
        %calculation of phi
        for k=2:l(1)+1
            for j=2:n(1)+1
                for i=2:m(1)+1                 
                    phi(1,i,j,k)=(b(i,j,k)-ae(1,i,j,k)*phi(1,i+1,j,k)-aw(1,i,j,k)*phi(1,i-1,j,k)-an(1,i,j,k)*phi(1,i,j+1,k) ...
                        -as(1,i,j,k)*phi(1,i,j-1,k)-at(1,i,j,k)*phi(1,i,j,k+1)-ab(1,i,j,k)*phi(1,i,j,k-1))/ap(1,i,j,k);

                end
            end
        end
        %Update boundary and Periodic condition
        for k=1:l(1)+2
            for j=1:n(1)+2
                for i=1:m(1)+2
                    phi(1,m(1)+2,j,k)=phi(1,m(1)+1,j,k);
                    phi(1,1,j,k)=phi(1,2,j,k);
                    phi(1,i,j,1)=phi(1,i,j,2);
                    phi(1,i,j,l(1)+2)=phi(1,i,j,l(1)+1);
                
                    phi(1,i,n(1)+2,k)=phi(1,i,2,k);
                    phi(1,i,1,k)=phi(1,i,n(1)+1,k);
                end
            end
        end
    end
      
    sum=0;
    %calculate sum of square of error
    for k=1:l(1)+2
        for j=1:n(1)+2
            for i=1:m(1)+2
                sum=sum+power(phi(1,i,j,k)-phi0(1,i,j,k),2);
            end
        end
    end
    L2norm=sqrt(sum);
   
    count=count+1;

%     disp(count)
%     disp(L2norm)
end
        for k=1:l(1)+2
            for j=1:n(1)+2
                for i=1:m(1)+2
                        pr(i,j,k)=phi(1,i,j,k);
                end
            end
        end

    
    
end